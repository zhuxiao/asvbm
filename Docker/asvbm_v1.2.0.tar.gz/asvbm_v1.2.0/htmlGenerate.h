#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include "extvab.h"
#include "constants.h"

using namespace std;

string escapeHtml(const std::string& str);
void Generatehtml(string figuresFilePath);
